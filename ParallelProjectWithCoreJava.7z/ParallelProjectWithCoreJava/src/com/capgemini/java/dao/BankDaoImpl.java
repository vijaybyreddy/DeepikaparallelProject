package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.capgemini.java.bean.Account;
import com.capgemini.java.bean.Transaction;

public class BankDaoImpl implements BankDao {
 
	Map<Long, Account> accountDetail=new HashMap<Long, Account>();
	Map<Integer, Transaction> transactionDetail=new HashMap<>();
	
	@Override
	public long addDetails(Account account) {
		accountDetail.put(account.getAccountNo(), account);
		return account.getAccountNo();
	}

	

	@Override
	public Map<Long, Account> accountDetails(Account account) {
		//Map<Long, Account> accountDetail=new HashMap<Long, Account>();
		accountDetail.put(account.getAccountNo(), account);
		return accountDetail;
	}



	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		long depositBalance=0; 
	
		Iterator<Account> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			Account acc=iterator.next();
		
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			depositBalance=(long)bal+depositAmount;
			acc.setBalance(depositBalance);
		}
		
	}
return depositBalance;
}



	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		long drawBalance=0; 
		
		Iterator<Account> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			Account acc=iterator.next();
		
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			drawBalance=(long)bal-withDrawAmount;
			acc.setBalance(drawBalance);
		}
		
	}
		return drawBalance;
	}



	



	@Override
	 public double balanceCheck() {
		double bal=0;
		Iterator<Account> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			Account acc=iterator.next();
		
		
		 bal=acc.getBalance();
	
		
		
	}
		return bal;
	}



	@Override
	public long fundDetails(long accountNo, long fundAmount) {
long fundBalance=0; 
		
		Iterator<Account> iterator=accountDetail.values().iterator();
		while(iterator.hasNext())
		{
			Account acc=iterator.next();
		
		long accNo=acc.getAccountNo();
		double bal=acc.getBalance();
		if(accNo==accountNo)
		{
			fundBalance=(long)bal-fundAmount;
			acc.setBalance(fundBalance);
		}
		
	}
		return fundBalance;
	}



	@Override
	public int addTransaction(Transaction transaction) {
		transactionDetail.put(transaction.getTransactionId(), transaction);
		return transaction.getTransactionId();
	}



	



	@Override
	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
		transactionDetail.put(transaction.getTransactionId(), transaction);
		return transactionDetail;
		
	}
		
	}

